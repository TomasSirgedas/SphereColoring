#pragma once

#include <cmath>

class XYZ
{
public:
   XYZ( double px, double py, double pz ) { set( px, py, pz ); }
   XYZ() { set( 0, 0, 0 ); }
   ~XYZ() {}
   void set( double px, double py, double pz ) { x = px; y = py; z = pz; }

   double len2() const { return x*x + y*y + z*z; }
   double len() const { return sqrt( len2() ); }
   double dist2( const XYZ& p ) const { return (*this - p).len2(); }
   double dist( const XYZ& p ) const { return (*this - p).len(); }

   XYZ operator-() const { return XYZ( -x, -y, -z ); }
   XYZ operator-( const XYZ& p ) const { return XYZ( x - p.x, y - p.y, z - p.z ); }
   XYZ operator+( const XYZ& p ) const { return XYZ( x + p.x, y + p.y, z + p.z ); }
   XYZ operator*( double iMul ) const { return XYZ( x * iMul, y * iMul, z * iMul ); }
   XYZ operator/( double iDiv ) const { return XYZ( x / iDiv, y / iDiv, z / iDiv ); }
   const XYZ& operator-=( const XYZ& p ) { return *this = *this - p; }
   const XYZ& operator+=( const XYZ& p ) { return *this = *this + p; }
   const XYZ& operator*=( double iMul ) { return *this = *this * iMul; }
   const XYZ& operator/=( double iDiv ) { return *this = *this / iDiv; }

   XYZ operator^( const XYZ& p ) { return XYZ( y*p.z-z*p.y, z*p.x-x*p.z, x*p.y-y*p.x ); }

   double operator*( const XYZ& p ) const { return x*p.x + y*p.y + z*p.z; }

   bool operator==( const XYZ& p ) const { return x == p.x && y == p.y && z == p.z; }
   bool operator!=( const XYZ& p ) const { return !(*this == p); }
   bool operator<( const XYZ& p ) const { return (z != p.z) ? (z < p.z) : (y != p.y) ? (y < p.y) : (x < p.x); }

public:
   double x, y, z;
};
