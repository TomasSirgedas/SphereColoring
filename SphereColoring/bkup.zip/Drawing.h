#pragma once

#include <QWidget>
#include "ui_Drawing.h"
#include <memory>

class Graph;
class Simulation;

class Drawing : public QWidget
{
   Q_OBJECT

public:
   Drawing( QWidget *parent = Q_NULLPTR );
   ~Drawing();

   QImage makeImage( const Graph& graph, double radius );
   void updateLabel();

private:
   void resizeEvent( QResizeEvent *event ) override;
   void mousePressEvent(QMouseEvent * event);

private:
   Ui::Drawing ui;

public:
   double _YRotation = 0;
   double _XRotation = 0;
   double _Zoom = 1.;
   double _Custom[10] = { 0 };
   QPoint _ClickPos;
   const Simulation* _Simulation;
};

