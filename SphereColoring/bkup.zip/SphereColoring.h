#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_SphereColoring.h"

#include "Simulation.h"
#include <QTimer>

class SphereColoring : public QMainWindow
{
   Q_OBJECT

public:
   SphereColoring( QWidget *parent = Q_NULLPTR );

   void redrawSim() const;

private:
   Ui::SphereColoringClass ui;

   Simulation _Simulation;
   QTimer _Timer;
};
