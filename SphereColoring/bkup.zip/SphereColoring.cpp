#include "SphereColoring.h"
#include "Drawing.h"
#include "Model.h"
#include <QDebug>

#include <vector>
#include <sstream>


using namespace std;


SphereColoring::SphereColoring(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

    _Simulation.init( shared_ptr<Graph>( new Graph( -1 ) ), 9.5 ); // 8.2 .. 9.77
    //_Simulation.init( shared_ptr<Graph>( new Graph( 0 ) ), 18 );
    //_Simulation.init( shared_ptr<Graph>( new Graph( 1 ) ), 26 );
    ui.drawing->_Simulation = &_Simulation;
        
    connect( ui.yRotationSlider, &QSlider::valueChanged, [this]( int ) {
       ui.drawing->_YRotation = ui.yRotationSlider->value() * 1.;
       redrawSim();
    } );
    connect( ui.xRotationSlider, &QSlider::valueChanged, [this]( int ) {
       ui.drawing->_XRotation = ui.xRotationSlider->value() * 1.;
       redrawSim();
    } );
    connect( ui.zoomSlider, &QSlider::valueChanged, [this]( int ) {
       ui.drawing->_Zoom = 1. + ui.zoomSlider->value()/100.*3.;
       redrawSim();
    } );

    connect( ui.lineEdit0, &QLineEdit::editingFinished, [this]() {
       ui.drawing->_Custom[0] = ui.lineEdit0->text().toDouble();
       redrawSim();
    } );
    connect( ui.lineEdit1, &QLineEdit::editingFinished, [this]() {
       //ui.drawing->_Custom[1] = ui.lineEdit1->text().toDouble();
       _Simulation._Radius = ui.lineEdit1->text().toDouble();
       _Simulation.normalizeVertices();
       redrawSim();
    } );
    connect( ui.stepButton, &QPushButton::pressed, [this]() {
       _Simulation.step();
       redrawSim();
    } );
    connect( ui.playButton, &QPushButton::pressed, [this]() {
       if ( _Timer.isActive() )
       {
          _Timer.stop();
          ui.playButton->setText( "Play" );
       }
       else
       {
          _Timer.start( 50 );
          ui.playButton->setText( "Pause" );
       }
    } );
    connect( &_Timer, &QTimer::timeout, [this]() {
       double error = _Simulation.step( 500 );
       ui.errorLabel->setText( "Err:" + QString::number( error ) );
       redrawSim();
    } );

    //connect( ui.permSlider, &QSlider::valueChanged, [this]( int ) {
    //   ui.drawing->_PermIndex = ui.permSlider->value();
    //   redrawSim();
    //} );
}

void SphereColoring::redrawSim() const { ui.drawing->updateLabel(); }