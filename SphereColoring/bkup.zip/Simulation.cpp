#include "Simulation.h"

void Simulation::init( std::shared_ptr<Graph> graph, double radius )
{
   _Graph = graph;
   
   _KeepNears = _Graph->calcKeepNear();
   _KeepFars = _Graph->calcKeepFar();

   _Radius = radius;
   normalizeVertices();
}


void Simulation::normalizeVertices()
{
   for ( Graph::Vertex& vtx : _Graph->_Vertices )
      vtx._Pos = vtx._Pos.normalized() * _Radius;
}

double Simulation::step()
{   
   double totalError = 0;
   vector<XYZ> vel( _Graph->_Vertices.size() );

   for ( const Graph::VertexPair& pr : _KeepNears )
   {
      XYZ a = _Graph->posOf( pr.a );
      XYZ b = _Graph->posOf( pr.b );
      double dist = a.distanceToPoint( b );
      if ( dist <= 1. )
         continue;

      vel[pr.a._Index] += (pr.a._Mtx.inverted() * (b-a)) * (dist-1) * .03;
      vel[pr.b._Index] += (pr.b._Mtx.inverted() * (a-b)) * (dist-1) * .03;
      totalError += dist-1;
   }
   for ( const Graph::VertexPair& pr : _KeepFars )
   {
      XYZ a = _Graph->posOf( pr.a );
      XYZ b = _Graph->posOf( pr.b );
      double dist = a.distanceToPoint( b );
      if ( dist >= 1. )
         continue;

      vel[pr.a._Index] += (pr.a._Mtx.inverted() * (a-b).normalized()) * (1-dist) * .03;
      vel[pr.b._Index] += (pr.b._Mtx.inverted() * (b-a).normalized()) * (1-dist) * .03;
      totalError += 1-dist;
   }

   // apply velocities
   for ( int i = 0; i < (int)vel.size(); i++ )
   {
      _Graph->_Vertices[i]._Pos += vel[i];
   }
   normalizeVertices();

   return totalError;
}

double Simulation::step( int numSteps )
{
   double tot = 0;
   for ( int i = 0; i < numSteps; i++ )
      tot += step();
   return tot / numSteps;
}