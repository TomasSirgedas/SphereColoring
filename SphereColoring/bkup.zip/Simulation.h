#pragma once

#include "Model.h"
#include <memory>

class Simulation
{
public:
   void init( std::shared_ptr<Graph> graph, double radius );
   void normalizeVertices();
   double step();
   double step( int numSteps );

public:
   double _Radius = 1;
   shared_ptr<Graph> _Graph;
   vector<Graph::VertexPair> _KeepNears;
   vector<Graph::VertexPair> _KeepFars;
};

