#include "Model.h"

#include <algorithm>
#include <map>


bool isClockwiseTri( const QPolygonF& poly )
{
   QPointF u = poly.at(1) - poly.at(0);
   QPointF v = poly.at(2) - poly.at(0);
   return u.x() * v.y() < u.y() * v.x();
}

QMatrix4x4 toMatrix( const XYZ& a, const XYZ& b, const XYZ& c )
{
   return QMatrix4x4( a.x(), b.x(), c.x(), 0,
                      a.y(), b.y(), c.y(), 0, 
                      a.z(), b.z(), c.z(), 0, 
                      0,     0,     0, 1 );
}

vector<int> canonicalRotation( vector<int> v )
{
   rotate( v.begin(), min_element( v.begin(), v.end() ), v.end() );
   return v;
}

vector<int> sorted( vector<int> v )
{
   sort( v.begin(), v.end() );
   return v;
}

uint32_t toBitFlag( const vector<int>& v )
{
   uint32_t ret = 0;
   for ( int x : v )
      ret |= 1u << x;
   return ret;
}

QMatrix4x4 translation( const XYZ& p ) { QMatrix4x4 m; m.translate( p ); return m; }

QMatrix4x4 map( const vector<XYZ>& a, const vector<XYZ>& b )
{
   if ( a.size() == 3 && b.size() == 3 )
      return toMatrix( b[0], b[1], b[2] ) * toMatrix( a[0], a[1], a[2] ).inverted();
   if ( a.size() == 4 && b.size() == 4 )
   {
      QMatrix4x4 m = ::map( { a[1]-a[0], a[2]-a[0], a[3]-a[0] }, { b[1]-b[0], b[2]-b[0], b[3]-b[0] } );
      return translation( b[0] ) * m * translation( -a[0] );
   }
   throw 777;
}

QMatrix4x4 pow( const QMatrix4x4& m, int power )
{
   QMatrix4x4 ret;
   for ( int i = 0; i < power; i++ )
      ret = ret * m;
   return ret;
}

bool fuzzyCompare( const QMatrix4x4& a, const QMatrix4x4& b )
{
   for ( int y = 0; y < 4; y++ )
      for ( int x = 0; x < 4; x++ )
         if ( abs( a(y,x) - b(y,x) ) >= 1e-5 )
            return false;
   return true;
}

bool contains( const vector<QPoint>& v, const QPoint& p )
{
   return find( v.begin(), v.end(), p ) != v.end();
}

//int matrixId( const QMatrix4x4& m )
//{
//   static vector<QMatrix4x4> s_matrices;
//   if ( s_matrices.empty() )
//   {
//      IcoSymmetry ico;
//      s_matrices.push_back( ico.map( {0,1,2}, {0,1,2} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {0,2,3} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {0,3,4} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {0,4,5} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {0,5,1} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {1,2,0} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {2,0,1} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {1,0,5} ) );
//      s_matrices.push_back( ico.map( {0,1,2}, {2,3,0} ) );
//   }
//   for ( int i = 0; i < (int) s_matrices.size(); i++ )
//      if ( fuzzyCompare( m, s_matrices[i] ) )
//         return i;
//   throw 777;
//}

// [0..2^18)
// [0..262144)
uint64_t matrixId( const QMatrix4x4& m )
{
   uint64_t ret = 0;
   ret = ret * 8 + ( int( m(0,0) / .24 ) + 3 );
   ret = ret * 8 + ( int( m(1,0) / .24 ) + 3 );
   ret = ret * 8 + ( int( m(2,0) / .24 ) + 3 );
   ret = ret * 8 + ( int( m(0,1) / .24 ) + 3 );
   ret = ret * 8 + ( int( m(1,1) / .24 ) + 3 );
   ret = ret * 8 + ( int( m(2,1) / .24 ) + 3 );
   return ret;
}




namespace
{
   bool isMissingEdge( const QPoint& a, const QPoint& b )
   {
      static vector<pair<QPoint, QPoint>> s_missingEdges = 
      { { {3,-3}, {3,-4} },
      { {3,-3}, {2,-2} },
      { {3,-2}, {4,-3} },
      { {2,-1}, {1,-1} },
      { {3,0}, {4,0} },
      { {4,-1}, {5,-1} },
      { {6,-1}, {6,0} },
      { {2,-2}, {1,-2} },
      { {2,-2}, {3,-3} } };
      for ( const auto& edge : s_missingEdges ) 
      {
         if ( edge.first == a && edge.second == b )
            return true;
         if ( edge.first == b && edge.second == a )
            return true;
      }
      return false;
   }
}

TileDots generateSphereColoringDots( int numExtensions )
{
   int EXTENSIONS = numExtensions-1;
   IcoSymmetry ico;
   XYZ ico0 = ico[0];
   XYZ ico01 = (( ico[0] + ico[1] ) / 2).normalized() * ico.radius();
   XYZ ico02 = (( ico[0] + ico[2] ) / 2).normalized() * ico.radius();
   XYZ ico012 = (( ico[0] + ico[1] + ico[2] ) / 3).normalized() * ico.radius();

   TileDots tileDots;
   tileDots.add( TileDot( 0, QPoint( 2, -3 ), ico0, 6 ) );
   {
      Perm colorPerm( { 0, 2, 6, 3, 5, 1, 4 } );
      unordered_map<int, unordered_map<int, int>> hexGridPosToIndex;

      // divide quadrilateral into two triangles, so that the hexpattern can be pinned to the icosahedron face's center
      for ( int quadPart = 0; quadPart < 2; quadPart++ )
      {
         QMatrix4x4 hexToModel = quadPart == 0 ? ::map( { XYZ( 2.27, -3.23, 0 ), XYZ( 14.5 + EXTENSIONS*7, -.5, 0 ), XYZ( 26/3. + EXTENSIONS*14./3, 26/3. + EXTENSIONS*14./3, 0 ), XYZ(0,0,1) }, { ico0, ico01, ico012, XYZ(0,0,0) } )
                                               : ::map( { XYZ( 2.27, -3.23, 0 ), XYZ( -.5, 12 - 1e-5 + EXTENSIONS*7, 0 ), XYZ( 26/3. + EXTENSIONS*14./3, 26/3. + EXTENSIONS*14./3, 0 ), XYZ(0,0,1) }, { ico0, ico02, ico012, XYZ(0,0,0) } );

         for ( int y = -3; y < 21 + EXTENSIONS*11; y++ )
            for ( int x = 0; x+y < 21 + EXTENSIONS*11; x++ )
            {
               //if ( y == -2 && x <= 1 ) continue;
               //if ( y == -3 && x != 2 ) continue;

               XYZ pos = hexToModel * XYZ( x, y, 0 );
               XYZ icoWeights = toMatrix( ico0, quadPart == 0 ? ico01 : ico02, ico012 ).inverted() * pos;
               if ( icoWeights.x() < 0 || icoWeights.y() < 0 || icoWeights.z() < 0 ) // check if pattern is past the surface
                  continue;

               Perm swapper = y < 0 && QPoint(x,y) != QPoint(2,-2) ? Perm({0,1,3,2,4,5,6}) : Perm(7);
               tileDots.add( TileDot( tileDots.size(), QPoint( x, y ), pos, (swapper * colorPerm)[mod(x+y*3, 7)] ) );
            }
      }

      QPoint symPoint0 = QPoint( 2, -3 );
      QPoint symPoint1 = QPoint( 4, 4 );
      auto isSymPoint = [&]( const QPoint& p ) { return p == symPoint0 || p == symPoint1; };

      vector<QPoint> dirs = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 }, { 1, -1 }, { -1, 1 } };
      for ( TileDot& tileDot : tileDots.arr() )
         for ( const QPoint& dir : dirs )
         {  
            const QPoint& pos = tileDot._GridPos;
            QPoint neighborPos = tileDot._GridPos + dir;

            if ( pos.x() + pos.y() <= 6 || neighborPos.x() + neighborPos.y() <= 6 )
            {
               if ( isMissingEdge( pos, neighborPos) )
                  continue;
            }
            else
            { 
               bool inSeamRow = pos.y() + neighborPos.y() == -1 || pos.x() + neighborPos.x() == -1;
               if ( inSeamRow )
               {
                  static vector<int> s_seamPattern = {1,1,1,1,0,1,1,0,1,0,1,1,0,1};
                  int seamPos = mod( pos.y() + neighborPos.y() == -1 ? pos.x() + neighborPos.x() : pos.y() + neighborPos.y() + 5, 14 );
                  if ( !s_seamPattern[seamPos] )
                     continue;
               }
            }


            if ( tileDots.isTileAt( neighborPos ) )
            {
               tileDot._Neighbors.push_back( TileDot::Neighbor( tileDots.tileAt( neighborPos )._Index, QMatrix4x4(), isSymPoint( neighborPos ) ) );
               continue;
            }


            auto safeAddNeighbor = [&]( const QPoint& pos, const vector<int>& newFace ) { if ( tileDots.isTileAt( pos ) ) tileDot._Neighbors.push_back( TileDot::Neighbor( tileDots.tileAt( pos )._Index, ico.map( {0,1,2}, newFace ), isSymPoint( pos ) ) ); };

            safeAddNeighbor( QPoint( EXTENSIONS*14+26-neighborPos.x()-neighborPos.y(), neighborPos.x() ), {2,0,1} );
            safeAddNeighbor( QPoint( neighborPos.y(), EXTENSIONS*14+26-neighborPos.x()-neighborPos.y() ), {1,2,0} );
            //if ( tileDot.isCenter() )
            //   continue;
            safeAddNeighbor( QPoint( neighborPos.y()+neighborPos.x()+3, -1-neighborPos.x() ), {0,2,3} );
            safeAddNeighbor( QPoint( -1-neighborPos.y(), neighborPos.y()+neighborPos.x()-2 ), {0,5,1} );
            safeAddNeighbor( QPoint( EXTENSIONS*14+29-neighborPos.x(), -1-neighborPos.y() ), {1,0,5} );
         }
   }
   tileDots.sortNeighbors();
   return tileDots;
}

void TileDots::sortNeighbors()
{
   for ( TileDot& tileDot : v )
   {
      sort( tileDot._Neighbors.begin(), tileDot._Neighbors.end(), [&]( const TileDot::Neighbor& a, const TileDot::Neighbor& b ) {
         XYZ posA = a._Mtx * v[a._Index]._Pos - tileDot._Pos;
         XYZ posB = b._Mtx * v[b._Index]._Pos - tileDot._Pos;
         return atan2( -posA.y(), -posA.x() ) > atan2( -posB.y(), -posB.x() );
      } );
   }
}


//
//
//Graph::Graph( const TileDots& tileDots )
//{
//   //vector<TileDot::Neighbor> poly = tileDots.polygonForEdge( TileDot::Neighbor { 18 }, TileDot::Neighbor { 19 } );
//
//   std::map<vector<int>, int> _PolyToVertex;
//
//   //vector<TileDot> tileDotsArr = tileDots.arr();
//   //rotate( tileDotsArr.begin(), tileDotsArr.begin()+1, tileDotsArr.end() );
//   for ( const TileDot& tileDot : tileDots.arr() )
//   for ( const TileDot::Neighbor& neighb : tileDot._Neighbors ) //if ( tileDot._Index != 257 ) if ( tileDot._Index != 454 ) if ( tileDot._Index != 455 )
//   {
//      //if ( tileDot._Index == 0 && neighb.M )
//
//      vector<TileDot::Neighbor> poly = tileDots.polygonForEdge( TileDot::Neighbor( tileDot._Index, QMatrix4x4(), false ), neighb );
//
//      //for ( const TileDot::Neighbor& a : poly ) 
//      //   qDebug() << a._Index << tileDots.posOf( a );
//
//      XYZ sum(0,0,0);
//      for ( const TileDot::Neighbor& a : poly ) sum += tileDots.posOf( a );
//      XYZ avgPos = sum / poly.size();
//
//      vector<int> polyVertexIndices;
//      for ( const TileDot::Neighbor& a : poly )
//         polyVertexIndices.push_back( a._Index );
//      polyVertexIndices = canonicalRotation( polyVertexIndices );
//      if ( tileDot._Index != polyVertexIndices[0] )
//         continue;
//
//      if ( !_PolyToVertex.count( polyVertexIndices ) )
//      {      
//         _Vertices.push_back( Vertex( (int) _Vertices.size(), avgPos ) );
//         _PolyToVertex[polyVertexIndices] = _Vertices.back()._Index;
//      }
//
//      //for ( const TileDot::Neighbor& a : poly )
//      //   matrixId( a._Mtx );
//   }
//
//   {
//      Graph::Tile tile;
//      tile._Color = tileDots[0]._Color;
//      vector<TileDot::Neighbor> poly = tileDots.polygonForEdge( TileDot::Neighbor( 0, QMatrix4x4(), false ), tileDots[0]._Neighbors[0] );
//      vector<int> polyVertexIndices;
//      for ( const TileDot::Neighbor& a : poly )
//         polyVertexIndices.push_back( a._Index );
//      int tileVertex = _PolyToVertex[canonicalRotation( polyVertexIndices )];
//      IcoSymmetry ico;
//      for ( int i = 0; i < 5; i++ )
//         tile._Vertices.push_back( Graph::VertexPtr( this, tileVertex, ico.map( { 0, 1, 2 }, { 0, i%5+1, (i+1)%5+1 } ) ) );
//      _Tiles.push_back( tile );
//   }
//
//   // second pass
//   for ( const TileDot& tileDot : tileDots.arr() ) if ( tileDot._Index != 0 )
//   {
//      Graph::Tile tile;
//      tile._Color = tileDot._Color;
//      for ( const TileDot::Neighbor& neighb : tileDot._Neighbors )
//      {
//         vector<TileDot::Neighbor> poly = tileDots.polygonForEdge( TileDot::Neighbor( tileDot._Index, QMatrix4x4(), false ), neighb );
//
//         vector<int> polyVertexIndices;
//         for ( const TileDot::Neighbor& a : poly )
//            polyVertexIndices.push_back( a._Index );
//         
//         QMatrix4x4 mtx;
//         {
//            int leastIndex = 999999999;
//            for ( const TileDot::Neighbor& a : poly ) if ( a._Index < leastIndex )
//            {
//               leastIndex = a._Index;
//               mtx = a._Mtx;
//            }
//         }
//
//         int tileVertex = _PolyToVertex[canonicalRotation( polyVertexIndices )];
//         tile._Vertices.push_back( Graph::VertexPtr( this, tileVertex, mtx ) );
//         
//
//         //if (  )
//         //{      
//         //   _Vertices.push_back( Vertex( (int) _Vertices.size(), avgPos ) );
//         //   _PolyToVertex[polyVertexIndices] = _Vertices.back()._Index;
//         //}
//      }
//      _Tiles.push_back( tile );
//   }
//}


Graph::Graph( int EXTENSIONS ) : EXTENSIONS( EXTENSIONS ), _HexCoords( EXTENSIONS )
{
   vector<QPoint> hexPts;
   for ( int y = 0; y < 12 + EXTENSIONS*7; y++ )
   for ( int x = 0; x < 12 + EXTENSIONS*7 && (x+y)*3 < 53 + EXTENSIONS*28; x++ )
   {
      if ( y*3 >= 35 + EXTENSIONS*14 && x+y >= 12 + EXTENSIONS*7 )
         continue;
      hexPts.push_back( QPoint( x, y ) );
   }

   if ( EXTENSIONS == -1 )
   {
      hexPts.push_back( QPoint( 0, 5 ) );
      hexPts.push_back( QPoint( 1, 5 ) );
      hexPts.push_back( QPoint( 2, 5 ) );
      hexPts.push_back( QPoint( 3, 5 ) );
      hexPts.push_back( QPoint( 4, 5 ) );
      hexPts.push_back( QPoint( 0, 6 ) );
      hexPts.push_back( QPoint( 1, 6 ) );
      hexPts.push_back( QPoint( 2, 6 ) );
   }
   
   vector<pair<QPoint, QPoint>> deletedEdges = {
      { QPoint(0, 0), QPoint(-1, 0) },
   { QPoint(0, 1), QPoint(1, 0) },
   { QPoint(1, 2), QPoint(2, 2) },
   { QPoint(0, 3), QPoint(1, 3) },
   };

   for ( int i = 0; i < EXTENSIONS+2; i++ )
   {
      deletedEdges.push_back( { QPoint( i*7 + 3, 2 ), QPoint( i*7 + 3, 3 ) } );
      deletedEdges.push_back( { QPoint( i*7 + 6, 2 ), QPoint( i*7 + 6, 3 ) } );
      deletedEdges.push_back( { QPoint( i*7 + 8, 2 ), QPoint( i*7 + 7, 3 ) } );
      deletedEdges.push_back( { QPoint( i*7 + 9, 2 ), QPoint( i*7 + 8, 3 ) } );
   }
   
   // 
   for ( const QPoint& hexPt : hexPts )
   {
      Tile tile;

      Perm colorPerm( { 2, 6, 3, 5, 1, 4, 0 } );
      Perm swapper = hexPt.y() < 3 ? Perm({0,2,1,3,4,5,6}) : Perm(7);
      tile._Color = (swapper * colorPerm)[mod(hexPt.x()+hexPt.y()*3, 7)];

      for ( int dir = 0; dir < 6; dir++ )
      {
         vector<QPoint> hexPos = { hexPt, hexPt+HexCoords::dir( dir ), hexPt+HexCoords::dir( dir+1 ) };
         for ( const auto& delEdge : deletedEdges )
            if ( contains( hexPos, delEdge.first ) && contains( hexPos, delEdge.second ) )
               hexPos = { delEdge.first, delEdge.second };

         if ( hexPos == vector<QPoint> { QPoint( 0, 0 ), QPoint( -1, 0 ) } )
            continue;
                  
         VertexPtr vtx = vertexAt( hexPos );
         if ( !vtx.isValid() )
         {
            Vertex newVertex( (int)_Vertices.size(), hexPos );
            _Vertices.push_back( newVertex );
            _HexIdToVertexIndex[newVertex.hexPosId()] = newVertex._Index;
            vtx = VertexPtr( newVertex._Index, QMatrix4x4() );
         }
         
         _Vertices[vtx._Index]._Tiles.push_back( TilePtr( (int) _Tiles.size(), vtx._Mtx.inverted() ) );

         if ( tile.hasVertex( vtx ) )
            continue;
         tile._Vertices.push_back( vtx );
      }

      _Tiles.push_back( tile );
   }
   Tile centerTile;
   int centerVertexId = _HexIdToVertexIndex[Vertex::hexPosId({QPoint(0,0), QPoint(1,-1), QPoint(0,-1)})];
   centerTile._Color = 6;
   centerTile._Vertices.push_back( VertexPtr( centerVertexId, _Ico.map( {0,1,2}, {0,1,2} ) ) );
   centerTile._Vertices.push_back( VertexPtr( centerVertexId, _Ico.map( {0,1,2}, {0,5,1} ) ) );
   centerTile._Vertices.push_back( VertexPtr( centerVertexId, _Ico.map( {0,1,2}, {0,4,5} ) ) );
   centerTile._Vertices.push_back( VertexPtr( centerVertexId, _Ico.map( {0,1,2}, {0,3,4} ) ) );
   centerTile._Vertices.push_back( VertexPtr( centerVertexId, _Ico.map( {0,1,2}, {0,2,3} ) ) );
   centerTile._IsSymmetrical = true;
   _Tiles.push_back( centerTile );
   _Vertices[centerVertexId]._Tiles.push_back( TilePtr( (int)_Tiles.size()-1, QMatrix4x4() ) );

   if ( EXTENSIONS == -1 )
   {
      Tile tile012;
      int id0 = _HexIdToVertexIndex[Vertex::hexPosId({QPoint(2,6), QPoint(1,7), QPoint(1,6)})];
      int id1 = _HexIdToVertexIndex[Vertex::hexPosId({QPoint(0,7), QPoint(1,7), QPoint(1,6)})];
      tile012._Color = 6;
      tile012._Vertices.push_back( VertexPtr( id0, _Ico.map( {0,1,2}, {0,1,2} ) ) );
      tile012._Vertices.push_back( VertexPtr( id1, _Ico.map( {0,1,2}, {0,1,2} ) ) );
      tile012._Vertices.push_back( VertexPtr( id0, _Ico.map( {0,1,2}, {2,0,1} ) ) );
      tile012._Vertices.push_back( VertexPtr( id1, _Ico.map( {0,1,2}, {2,0,1} ) ) );
      tile012._Vertices.push_back( VertexPtr( id0, _Ico.map( {0,1,2}, {1,2,0} ) ) );
      tile012._Vertices.push_back( VertexPtr( id1, _Ico.map( {0,1,2}, {1,2,0} ) ) );
      tile012._IsSymmetrical = true;
      _Tiles.push_back( tile012 );
      _Vertices[id0]._Tiles.push_back( TilePtr( (int)_Tiles.size()-1, QMatrix4x4() ) );
      _Vertices[id1]._Tiles.push_back( TilePtr( (int)_Tiles.size()-1, QMatrix4x4() ) );
   }

   // remove duplicate vertex _Tiles
   {
      for ( Vertex& vtx : _Vertices )
      {
         for ( int i = (int) vtx._Tiles.size()-1; i >= 0; i-- )
         {
            bool isDup = false;
            for ( int k = i+1; k < (int) vtx._Tiles.size(); k++ )
               if ( vtx._Tiles[i] == vtx._Tiles[k] )
                  isDup = true;

            if ( isDup )
               vtx._Tiles.erase( vtx._Tiles.begin() + i );
         }
      }
   }

   // calc vertex neighbors
   {
      for ( const Graph::Tile& tile : _Tiles )
      {
         for ( int i = 0; i < (int)tile._Vertices.size(); i++ )
         {
            const VertexPtr& a = tile._Vertices[i];
            const VertexPtr& b = tile._Vertices[(i+1)%tile._Vertices.size()];
            _Vertices[a._Index]._Neighbors.push_back( VertexPtr( b._Index, a._Mtx.inverted() * b._Mtx ) );
         }
      }
   }
   if ( EXTENSIONS == 0 )
   {
      int id = _HexIdToVertexIndex[Vertex::hexPosId({QPoint(6,11), QPoint(6,12), QPoint(5,12)})];
      if ( _Vertices[id]._Neighbors.size() == 1 )
      {
         _Vertices[id]._Neighbors.push_back( _Vertices[id]._Neighbors[0].premul( _Ico.map( {0,1,2}, {2,0,1} ) ) );
         _Vertices[id]._Neighbors.push_back( _Vertices[id]._Neighbors[0].premul( _Ico.map( {0,1,2}, {1,2,0} ) ) );
         _Vertices[id]._Tiles.push_back( TilePtr( _Vertices[id]._Tiles[0]._Index, _Ico.map( {0,1,2}, {2,0,1} ) ) );
         _Vertices[id]._Tiles.push_back( TilePtr( _Vertices[id]._Tiles[0]._Index, _Ico.map( {0,1,2}, {1,2,0} ) ) );
         _Vertices[id]._IsSymmetrical = true;
      }
   }


   for ( Vertex& vtx : _Vertices )
      vtx._Pos = originalPosOf( VertexPtr( vtx._Index, QMatrix4x4() ) );
}

bool Graph::TilePtr::operator==( const TilePtr& rhs ) const 
{ 
   return _Index == rhs._Index && matrixId( _Mtx ) == matrixId( rhs._Mtx );
}

XYZ avg( const vector<XYZ>& pts )
{
   XYZ sum(0,0,0);
   for ( const XYZ& pt : pts )
      sum += pt;
   return sum/pts.size();
}

XYZ Graph::originalPosOf( const VertexPtr& vtx ) const
{
   vector<XYZ> pts;
   for ( const QPoint& hexPt : _Vertices[vtx._Index]._HexPos )
      pts.push_back( _HexCoords.toIcoCoord( hexPt ) );
   return vtx._Mtx * avg( pts );
}

XYZ Graph::posOf( const VertexPtr& vtx ) const
{
   return vtx._Mtx * _Vertices[vtx._Index]._Pos;
}

uint64_t Graph::VertexPtr::id() const
{
   return _Index * (1LL<<18) + matrixId( _Mtx );
}

Graph::VertexPtr Graph::vertexAt( const vector<QPoint>& hexPos ) const
{
   int64_t vtxId = Vertex::hexPosId( hexPos );
   if ( _HexIdToVertexIndex.count( vtxId ) )
      return VertexPtr( _HexIdToVertexIndex.at( vtxId ), QMatrix4x4() );

   vtxId = Vertex::hexPosId( _HexCoords.rotatedCW( hexPos ) );
   if ( _HexIdToVertexIndex.count( vtxId ) )
      return VertexPtr( _HexIdToVertexIndex.at( vtxId ), _Ico.map( {0,1,2}, {0,2,3} ) );

   vtxId = Vertex::hexPosId( _HexCoords.rotated012CCW( hexPos ) );
   if ( _HexIdToVertexIndex.count( vtxId ) )
      return VertexPtr( _HexIdToVertexIndex.at( vtxId ), _Ico.map( {0,1,2}, {2,0,1} ) );

   vtxId = Vertex::hexPosId( _HexCoords.rotated012CW( hexPos ) );
   if ( _HexIdToVertexIndex.count( vtxId ) )
      return VertexPtr( _HexIdToVertexIndex.at( vtxId ), _Ico.map( {0,1,2}, {1,2,0} ) );

   vtxId = Vertex::hexPosId( _HexCoords.rotated01( hexPos ) );
   if ( _HexIdToVertexIndex.count( vtxId ) )
      return VertexPtr( _HexIdToVertexIndex.at( vtxId ), _Ico.map( {0,1,2}, {1,0,5} ) );

   return VertexPtr( -1, QMatrix4x4() );
}

vector<Graph::VertexPtr> Graph::neighbors( const VertexPtr& vtx ) const
{
   vector<Graph::VertexPtr> ret;
   
   for ( const Graph::VertexPtr& neighb : _Vertices[vtx._Index]._Neighbors )
      ret.push_back( neighb.premul( vtx._Mtx ) );

   return ret;
}

vector<Graph::VertexPtr> Graph::neighbors( const VertexPtr& vtx, int depth ) const
{
   unordered_set<uint64_t> st;
   vector<Graph::VertexPtr> ret;

   neighbors( vtx, depth, ret, st );
   ret.erase( ret.begin() );

   return ret;
}

void Graph::neighbors( const VertexPtr& vtx, int depth, vector<Graph::VertexPtr>& v, unordered_set<uint64_t>& st ) const
{
   uint64_t id = vtx.id();
   if ( !st.count( id ) )
   {
      st.insert( id );
      v.push_back( vtx );
   }

   if ( depth <= 0 )
      return;

   vector<Graph::VertexPtr> ret;

   for ( const Graph::VertexPtr& neighb : _Vertices[vtx._Index]._Neighbors )
      neighbors( neighb.premul( vtx._Mtx ), depth-1, v, st );
}

int Graph::colorOf( const TilePtr& tile ) const
{
   Perm perm = _Ico.colorPermOf( tile._Mtx );
   return perm[_Tiles[tile._Index]._Color];
}

//vector<int> Graph::colorsAt( const VertexPtr& vtx ) const
//{
//   Perm perm = _Ico.colorPermOf( vtx._Mtx );
//
//   vector<int> ret;
//   for ( const TilePtr& tile : _Vertices[vtx._Index]._Tiles )
//      ret.push_back( perm[ colorOf( tile ) ] );
//   return ret;
//}
vector<int> Graph::colorsAt( const VertexPtr& vtx ) const
{
   vector<int> ret;
   for ( const TilePtr& tile : tilesAt( vtx ) )
      ret.push_back( colorOf( tile ) );
   return ret;
}

uint32_t Graph::colorBits( const VertexPtr& vtx ) const
{
   return toBitFlag( colorsAt( vtx ) );
}

vector<Graph::TilePtr> Graph::tilesAt( const VertexPtr& vtx ) const
{
   vector<TilePtr> ret;   
   for ( const TilePtr& tile : _Vertices[vtx._Index]._Tiles )
      ret.push_back( tile.premul( vtx._Mtx ) );
   return ret;
}

Graph::TilePtr Graph::tileWithColor( const VertexPtr& vtx, int color ) const
{
   for ( const TilePtr& tile : tilesAt( vtx ) )
      if ( colorOf( tile ) == color )
         return tile;
   return TilePtr();
}

bool Graph::canBeClose( const VertexPtr& a, const VertexPtr& b ) const
{
   for ( const TilePtr& tileA : tilesAt( a ) )
   {
      TilePtr tileB = tileWithColor( b, colorOf( tileA ) );
      if ( tileB.isValid() && !eq( tileA, tileB ) )
         return false;
   }
   return true;
}

bool Graph::canBeFar( const VertexPtr& a, const VertexPtr& b ) const
{
   for ( const TilePtr& tileA : tilesAt( a ) )
   {
      TilePtr tileB = tileWithColor( b, colorOf( tileA ) );
      if ( tileB.isValid() && eq( tileA, tileB ) )
         return false;
   }
   return true;
}

bool Graph::eq( const TilePtr& a, const TilePtr& b ) const
{
   if ( a._Index != b._Index )
      return false;
   if ( _Tiles[a._Index]._IsSymmetrical )
      return true;
   return matrixId( a._Mtx ) == matrixId( b._Mtx );
}

bool Graph::eq( const VertexPtr& a, const VertexPtr& b ) const
{
   if ( a._Index != b._Index )
      return false;
   if ( _Vertices[a._Index]._IsSymmetrical )
      return true;
   return matrixId( a._Mtx ) == matrixId( b._Mtx );
}

vector<Graph::VertexPtr> Graph::rawVertices() const
{
   vector<VertexPtr> ret;
   for ( const Vertex& vtx : _Vertices )
      ret.push_back( VertexPtr( vtx._Index, QMatrix4x4() ) );
   return ret;
}

vector<Graph::VertexPair> Graph::calcKeepNear() const
{
   vector<VertexPair> ret;
   for ( const VertexPtr& vtx : rawVertices() )
      for ( const Graph::VertexPtr& neighb : neighbors( vtx, 3 ) )
         if ( !canBeFar( vtx, neighb ) )
            ret.push_back( { vtx, neighb } );
   return ret;
}

vector<Graph::VertexPair> Graph::calcKeepFar() const
{
   vector<VertexPair> ret;
   for ( const VertexPtr& vtx : rawVertices() )
      for ( const Graph::VertexPtr& neighb : neighbors( vtx, 6 ) )
         if ( !canBeClose( vtx, neighb ) )
            ret.push_back( { vtx, neighb } );
   return ret;
}
