#include "Drawing.h"
#include <QPainter>
#include <QMatrix4x4>
#include <QBrush>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <QMouseEvent>

#include "Model.h"
#include "Simulation.h"

using namespace std;

const vector<uint32_t> COLORS = { 0xFFED1D26, 0xFF3F47CB, 0xFFFFF200, 0xFFA349A4, 0xFF22B14C, 0xFFFF7F27, 0xFF00EEEE, 0xFFFFFFFF, 0xFF000000, 0xFF808080 };

//Perm finalColorPerm({6, 2, 0, 3, 4, 1, 5});
QColor tileColor( int idx ) { vector<int> perm = {5, 1, 0, 4, 3, 2, 6}; return QColor::fromRgba( COLORS[perm[idx]] ); }
QColor withAlpha( const QColor& color, int alpha ) { return QColor( color.red(), color.green(), color.blue(), alpha ); }
//QColor tileColor( int idx ) { return QColor::fromRgba( COLORS[idx] ); }






Drawing::Drawing( QWidget *parent )
   : QWidget( parent )
{
   ui.setupUi( this );
}

Drawing::~Drawing()
{
}

void Drawing::resizeEvent( QResizeEvent *event )
{
   updateLabel();
}

void Drawing::updateLabel()
{         
   if ( _Simulation )
      ui.label->setPixmap( QPixmap::fromImage( makeImage( *_Simulation->_Graph, _Simulation->_Radius ) ) );
}

void Drawing::mousePressEvent( QMouseEvent* event )
{
   _ClickPos = event->pos();
   updateLabel();
}



//QImage Drawing::makeImage()
//{
//   QSize size = this->size();
//   QImage image( size, QImage::Format_RGB888 );
//
//   QPainter painter( &image );
//
//   painter.setRenderHint( QPainter::Antialiasing, true );   
//
//   QMatrix4x4 modelToBitmap;
//   modelToBitmap.translate( size.width() / 2, size.height() / 2, 0 );
//   modelToBitmap.rotate( _XRotation, 1, 0, 0 );
//   modelToBitmap.rotate( _YRotation, 0, 1, 0 );
//   modelToBitmap.scale( size.height() / 4. );
//   modelToBitmap.scale( 1, -1 );
//   modelToBitmap.scale( _Zoom );
//   
//   IcoSymmetry ico;
//   XYZ ico0 = ico[0];
//   XYZ ico01 = (( ico[0] + ico[1] ) / 2).normalized() * ico.radius();
//   XYZ ico02 = (( ico[0] + ico[2] ) / 2).normalized() * ico.radius();
//   XYZ ico012 = (( ico[0] + ico[1] + ico[2] ) / 3).normalized() * ico.radius();
//   XYZ ico015 = (( ico[0] + ico[1] + ico[5] ) / 3).normalized() * ico.radius();
//   XYZ ico1 = ico[1];
//   
//   //TileDots tileDots = generateSphereColoringDots( _Custom[0] );
//   //Graph graph( tileDots );
//   
//   int EXTENSIONS = _Custom[0];
//   HexCoords hexCoords( EXTENSIONS );
//   Graph graph( EXTENSIONS );
//
//   for ( int stage : { 0, 3, 4 } )
//   for ( const IcoSymmetry::Config& config : ico.matrices() )
//   {
//      const QMatrix4x4& m = config.m;
//
//      auto toBitmap = [&]( const XYZ& pos ) { return ( modelToBitmap * m * pos ).toPointF(); };
//
//      QPolygonF poly = QVector<QPointF> { toBitmap( ico0 )
//                                        , toBitmap( ico01 )
//                                        , toBitmap( ico012 )
//                                        , toBitmap( ico02 ) };
//
//      if ( !isClockwiseTri( poly ) )
//         continue;
//
//      if ( stage == 0 )
//      {
//         painter.setPen( QColor( 0, 0, 0, 30 ) );
//         painter.setBrush( QBrush( QColor( 255, 0, 0, 30 ) ) );
//         painter.drawPolygon( poly );
//      }
//      //if ( config.state == vector<int>{0,0,0,0} )
//      //if ( stage == 1 )
//      //{
//      //   painter.setPen( QColor( 0, 0, 0, 80 ) );
//      //   for ( const TileDot& tileDot : tileDots.arr() )
//      //   for ( const TileDot::Neighbor& neighbor : tileDot._Neighbors )
//      //   {
//      //      const TileDot& neighb = tileDots[neighbor._Index];
//      //      //painter.drawLine( ( modelToBitmap * m * tileDot._Pos ).toPointF(), ( modelToBitmap * m * neighbor._Mtx * neighb._Pos ).toPointF() );
//      //   }
//      //}
//
//      //if ( config.state == vector<int>{0,0,0,0} )
//      //if ( stage == 2 )
//      //{
//      //   painter.setPen( Qt::NoPen );
//
//      //   //// draw icosahedron vertex color
//      //   //{
//      //   //   vector<int> colorPerm = ico.colorPerm( m );
//      //   //   painter.setPen( Qt::NoPen );
//      //   //   painter.setBrush( tileColor( colorPerm[0] ) );
//      //   //   painter.drawEllipse( ( modelToBitmap * m * ( ico[0] ) ).toPointF(), 5, 5 );
//      //   //}
//      //            
//      //   Perm perm( { ico.id( m*ico[0] )%6, ico.id( m*ico[1] )%6, ico.id( m*ico[2] )%6, ico.id( m*ico[3] )%6, ico.id( m*ico[4] )%6, ico.id( m*ico[5] )%6, 6} );        
//      //        
//      //   for ( const TileDot& tileDot : tileDots.arr() )
//      //   {
//      //      painter.setPen( Qt::NoPen );
//      //      painter.setBrush( tileColor( perm[tileDot._Color] ) );
//      //      double radius = 2;
//      //      QPointF dotPos = toBitmap( tileDot._Pos );
//      //      painter.drawEllipse( dotPos, radius, radius );
//
//      //      painter.setPen( QColor( 0,0,0,128 ) );
//      //      //painter.drawText( dotPos, QString::number( tileDot._Index ) );
//      //      painter.drawText( dotPos, QString::number( tileDot._GridPos.x() ) + "," + QString::number( tileDot._GridPos.y() ) );
//
//      //      if ( QLineF( QPointF( _ClickPos ), dotPos ).length() < 5 )
//      //      {             
//      //         stringstream ss;
//      //         for ( auto n : tileDot._Neighbors )
//      //            ss << n._Index << " ";
//      //         qDebug() << tileDot._GridPos << "  index = " << tileDot._Index << QString::fromStdString( ss.str() );
//      //      }
//      //   }
//
//      //   painter.setPen( QColor( 0, 0, 0 ) );
//      //   painter.drawText( toBitmap(ico0*.5 + ico012*.5 ), QString::number( config.state[0] ) + QString::number( config.state[1] ) + QString::number( config.state[2] ) + QString::number( config.state[3] ) );
//
//
//      //   if ( config.state == vector<int>{0,0,0,0} )
//      //   {
//      //      painter.setPen( Qt::NoPen );
//      //      //painter.setBrush( QColor( 0, 0, 0, 32 ) );
//      //      //for ( const auto& vtx : graph._Vertices )
//      //      //   painter.drawEllipse( toBitmap( vtx._Pos ), 2, 2 );
//
//      //      //painter.setPen( QColor( 255, 0, 0, 64 ) );
//      //      //painter.setBrush( QColor( 0, 255, 0, 8 ) );
//      //      for ( const Graph::Tile& tile : graph._Tiles )
//      //      {
//      //         painter.setBrush( withAlpha( tileColor( perm[tile._Color] ), 128 ) );
//      //         QPolygonF poly;
//      //         for ( const Graph::VertexPtr& vtx : tile._Vertices )
//      //            poly.append( toBitmap( vtx.pos() ) );
//      //         painter.drawPolygon( poly );
//      //      }
//      //   }
//      //}
//      //if ( config.state == vector<int>{0,0,0,0} )
//      //if ( stage == 3 )
//      //{
//      //   Perm quadPerm( { ico.id( m*ico[0] )%6, ico.id( m*ico[1] )%6, ico.id( m*ico[2] )%6, ico.id( m*ico[3] )%6, ico.id( m*ico[4] )%6, ico.id( m*ico[5] )%6, 6} );        
//
//      //   vector<QPoint> pts;
//      //   for ( int y = 0; y < 12 + EXTENSIONS*7; y++ )
//      //   for ( int x = 0; x < 12 + EXTENSIONS*7 && (x+y)*3 < 53 + EXTENSIONS*28; x++ )
//      //   {
//      //      if ( y*3 >= 35 + EXTENSIONS*14 && x+y >= 12 + EXTENSIONS*7 )
//      //         continue;
//      //      pts.push_back( QPoint( x, y ) );
//      //   }
//
//      //   if ( EXTENSIONS == -1 )
//      //   {
//      //      pts.push_back( QPoint( 0, 5 ) );
//      //      pts.push_back( QPoint( 1, 5 ) );
//      //      pts.push_back( QPoint( 2, 5 ) );
//      //      pts.push_back( QPoint( 3, 5 ) );
//      //      pts.push_back( QPoint( 4, 5 ) );
//      //      pts.push_back( QPoint( 0, 6 ) );
//      //      pts.push_back( QPoint( 1, 6 ) );
//      //      pts.push_back( QPoint( 2, 6 ) );
//      //   }
//
//      //   for ( const QPoint& pt : pts )
//      //   {
//      //      //QPoint h( x, y );
//      //      //if ( config.state == vector<int>{1,1,0,0} )
//      //      //   h = QPoint( y+x, -1-x );
//      //      //if ( config.state == vector<int>{1,0,0,0} )
//      //      //   h = QPoint( 23-y-x+EXTENSIONS*14, 6+x );
//      //      //if ( config.state == vector<int>{2,0,0,0} )
//      //      //   h = QPoint( y-6, 29-x-y+EXTENSIONS*14 );
//
//      //      XYZ pos = hexCoords.toIcoCoord( pt );
//      //      if ( QLineF( toBitmap( pos ), _ClickPos ).length() < 3 )
//      //         qDebug() << pt;
//
//      //      vector<XYZ> perim;
//      //      for ( const QPoint& offset : { QPoint( 0, 1 ), QPoint( 1, 0 ), QPoint( 1, -1 ), QPoint( 0, -1 ), QPoint( -1, 0 ), QPoint( -1, 1 ) } )
//      //         perim.push_back( hexCoords.toIcoCoord( pt + offset ) );
//
//      //      int alpha = config.state == vector<int>{0,0,0,0} ? 255 : 128;
//      //      //int alpha = config.state[1] == 0 && config.state[2] == 0 && config.state[3] == 0 ? 128 : 32;
//      //      painter.setPen( Qt::NoPen );
//      //      //painter.setBrush( QColor( 255, 255, 255, alpha ) );
//      //      //painter.setBrush( withAlpha( tileColor( config.state[0]+1 ), alpha ) );
//
//      //      Perm colorPerm( { 2, 6, 3, 5, 1, 4, 0 } );
//      //      Perm swapper = pt.y() < 3 /*&& QPoint(x,y) != QPoint(2,-2)*/ ? Perm({0,2,1,3,4,5,6}) : Perm(7);
//      //      int color = (swapper * colorPerm)[mod(pt.x()+pt.y()*3, 7)];
//      //      painter.setBrush( withAlpha( tileColor( quadPerm[color] ), alpha ) );
//
//      //      painter.drawEllipse( toBitmap( pos ), 2, 2 );
//
//      //      {
//      //         painter.setBrush( withAlpha( tileColor( quadPerm[color] ), alpha ) );
//      //         //painter.setPen( QColor( 0,0,0,alpha ) );
//      //         QPolygonF poly;
//      //         for ( int i = 0; i < 6; i++ )
//      //            poly.append( toBitmap( (pos+perim[i]+perim[(i+1)%6])/3 ) );
//      //         painter.drawPolygon( poly );
//      //      }
//
//
//      //      painter.setPen( QColor( 0,0,0,alpha ) );
//      //      //painter.drawText( toBitmap( pos ), QString::number( h.x() ) + "," + QString::number( h.y() ) );
//      //   }
//      //}
//      if ( stage == 3 )
//      {
//         Perm quadPerm( { ico.id( m*ico[0] )%6, ico.id( m*ico[1] )%6, ico.id( m*ico[2] )%6, ico.id( m*ico[3] )%6, ico.id( m*ico[4] )%6, ico.id( m*ico[5] )%6, 6} );        
//                  
//         for ( const Graph::Tile& tile : graph._Tiles )
//         {
//            int alpha = config.state == vector<int>{0,0,0,0} ? 255 : 64;
//            painter.setPen( Qt::NoPen );
//            painter.setBrush( withAlpha( tileColor( quadPerm[tile._Color] ), alpha ) );
//            
//            {
//               QPolygonF poly;
//               for ( const Graph::VertexPtr& vtx : tile._Vertices )
//                  poly.append( toBitmap( graph.posOf( vtx ) ) );
//               painter.drawPolygon( poly );
//            }
//         }
//      }
//      if ( stage == 4 && config.state == vector<int>{0,0,0,0} )
//      {
//         Perm quadPerm = ico.colorPermOf( m );
//
//         //for ( const Graph::Tile& tile : graph._Tiles )
//         //{
//         //   painter.setPen( Qt::NoPen );
//         //   painter.setBrush( QColor( 0,0,0,64 ) );
//
//         //   {
//         //      for ( const Graph::VertexPtr& vtx : tile._Vertices )
//         //         painter.drawEllipse( toBitmap( graph.posOf( vtx ) ), 2, 2 );
//         //   }
//         //}
//         Graph::VertexPtr clickVtx;
//         for ( const Graph::Vertex& vtx : graph._Vertices )
//         {
//            painter.setPen( Qt::NoPen );
//            painter.setBrush( QColor( 0,0,0,64 ) );
//            painter.drawEllipse( toBitmap( graph.posOf( Graph::VertexPtr( vtx._Index, QMatrix4x4() ) ) ), 2, 2 );
//            if ( QLineF( _ClickPos, toBitmap( graph.posOf( Graph::VertexPtr( vtx._Index, QMatrix4x4() ) ) ) ).length() < 3 )
//               clickVtx = Graph::VertexPtr( vtx._Index, QMatrix4x4() );
//         }
//
//         if ( clickVtx.isValid() )
//         {
//            ////for ( const Graph::VertexPtr& neighb : graph._Vertices[clickVtx._Index]._Neighbors )
//            //for ( const Graph::VertexPtr& neighb : graph.neighbors( graph[clickVtx._Index], 3 ) )
//            //{
//            //   painter.setPen( Qt::NoPen );
//            //   painter.setBrush( QColor( 255,255,255,192 ) );
//            //   painter.drawEllipse( toBitmap( graph.posOf( neighb ) ), 2, 2 );
//            //}
//
//
//            //for ( const Graph::VertexPtr& neighb : graph.neighbors( graph[clickVtx._Index], 6 ) )
//            ////const Graph::VertexPtr& neighb = graph[clickVtx._Index];
//            //{
//            //   int r = 8;
//            //   for ( int col : graph.colorsAt( neighb ) )
//            //   {
//            //      painter.setPen( Qt::NoPen );
//            //      painter.setBrush( withAlpha( tileColor( quadPerm[col] ), 255 ) );
//            //      painter.drawEllipse( toBitmap( graph.posOf( neighb ) ), r, r );
//            //      r -= 2;
//            //   }
//            //}
//
//            //vector<Graph::VertexPair> keepNear = graph.calcKeepNear();
//            //vector<Graph::VertexPair> keepFar  = graph.calcKeepFar();
//
//            //for ( const auto& pr : keepNear ) if ( graph.eq( pr.a, clickVtx ) )
//            //{
//            //   painter.setBrush( QColor(0,0,0,128) );
//            //   painter.drawEllipse( toBitmap( graph.posOf( pr.b ) ), 3, 3 );               
//            //}
//
//            //for ( const Graph::VertexPtr& neighb : graph.neighbors( graph[clickVtx._Index], 6 ) )
//            //   if ( !graph.canBeClose( clickVtx, neighb ) )
//            //   {
//            //      //painter.setPen( QColor(0,0,128) );
//            //      //painter.drawLine( toBitmap( graph.posOf( clickVtx ) ), toBitmap( graph.posOf( neighb ) ) );
//
//            //      painter.setBrush( QColor(0,0,0,128) );
//            //      painter.drawEllipse( toBitmap( graph.posOf( neighb ) ), 3, 3 );
//            //   }
//
//            //for ( const Graph::VertexPtr& neighb : graph.neighbors( graph[clickVtx._Index], 6 ) )
//            //   if ( graph.tileWithColor( neighb, 0 ).isValid() )
//            //   {
//            //      //painter.setPen( QColor(0,0,128) );
//            //      //painter.drawLine( toBitmap( graph.posOf( clickVtx ) ), toBitmap( graph.posOf( neighb ) ) );
//
//            //      painter.setBrush( QColor(0,0,0,128) );
//            //      painter.drawEllipse( toBitmap( graph.posOf( neighb ) ), 3, 3 );
//            //   }
//         }
//
//         //{
//         //   int idx = 0;
//         //   painter.setPen( QColor(0,0,0) );
//         //   for ( const Graph::VertexPtr& vtx : graph._Tiles[0]._Vertices )
//         //   {
//         //      painter.drawText( toBitmap( graph.posOf( vtx ) ), QString::number( idx ) );
//         //      idx++;
//         //   }
//         //}
//      }
//   }
//
//   return image;
//}

QImage Drawing::makeImage( const Graph& graph, double radius )
{
   QSize size = this->size();
   QImage image( size, QImage::Format_RGB888 );
   image.fill( QColor( 0, 0, 0 ) );

   QPainter painter( &image );

   painter.setRenderHint( QPainter::Antialiasing, true );   

   QMatrix4x4 modelToBitmap;
   modelToBitmap.translate( size.width() / 2, size.height() / 2, 0 );
   modelToBitmap.rotate( _XRotation, 1, 0, 0 );
   modelToBitmap.rotate( _YRotation, 0, 1, 0 );
   modelToBitmap.scale( size.height() / radius * .46 );
   modelToBitmap.scale( 1, -1 );
   modelToBitmap.scale( _Zoom );

   IcoSymmetry ico;
   XYZ ico0 = ico[0].normalized() * radius;
   XYZ ico01 = (( ico[0] + ico[1] ) / 2).normalized() * radius;
   XYZ ico02 = (( ico[0] + ico[2] ) / 2).normalized() * radius;
   XYZ ico012 = (( ico[0] + ico[1] + ico[2] ) / 3).normalized() * radius;
   XYZ ico015 = (( ico[0] + ico[1] + ico[5] ) / 3).normalized() * radius;
   XYZ ico1 = ico[1].normalized() * radius;

   //TileDots tileDots = generateSphereColoringDots( _Custom[0] );
   //Graph graph( tileDots );
   //int EXTENSIONS = _Custom[0]-1;
   //Graph graph( EXTENSIONS );

   for ( int stage : { 0, 1, 2 } )
      for ( const IcoSymmetry::Config& config : ico.matrices() )
      {
         const QMatrix4x4& m = config.m;

         auto toBitmap = [&]( const XYZ& pos ) { return ( modelToBitmap * m * pos ).toPointF(); };

         QPolygonF poly = QVector<QPointF> { toBitmap( ico0 )
            , toBitmap( ico01 )
            , toBitmap( ico012 )
            , toBitmap( ico02 ) };

         if ( !isClockwiseTri( poly ) )
            continue;

         if ( stage == 0 )
         {
            painter.setPen( QColor( 0, 0, 0, 30 ) );
            painter.setBrush( QBrush( QColor( 255, 0, 0, 30 ) ) );
            painter.drawPolygon( poly );
         }
         if ( stage == 1 )
         {
            Perm quadPerm = ico.colorPermOf( m );

            int alpha = 64;
            if ( config.state == vector<int>{0,0,0,0} )
               alpha = 255;
            if ( config.state == vector<int>{1,0,0,0} 
              || config.state == vector<int>{2,0,0,0} )
               alpha = 128;
            //int alpha = config.state == vector<int>{0,0,0,0} ? 255 : 64;

            for ( const Graph::Tile& tile : graph._Tiles )
            {
               painter.setPen( Qt::NoPen );
               painter.setBrush( withAlpha( tileColor( quadPerm[tile._Color] ), alpha ) );

               {
                  QPolygonF poly;
                  for ( const Graph::VertexPtr& vtx : tile._Vertices )
                     poly.append( toBitmap( graph.posOf( vtx ) ) );
                  painter.drawPolygon( poly );
               }
            }
         }
         if ( stage == 2 && config.state == vector<int>{0,0,0,0} )
         {
            const double TOLERANCE = 1e-5;

            painter.setPen( QPen( QColor(0,255,0,128), 2 ) );
            painter.setBrush( Qt::NoBrush );
            for ( const auto& pr : _Simulation->_KeepNears )
            {
               XYZ a = _Simulation->_Graph->posOf( pr.a );
               XYZ b = _Simulation->_Graph->posOf( pr.b );
               if ( a.distanceToPoint( b ) < 1. + TOLERANCE )
                  continue;

               painter.drawLine( toBitmap( a ), toBitmap( b ) );
            }
            painter.setPen( QPen( QColor(255,0,0,128), 2 ) );
            painter.setBrush( Qt::NoBrush );
            for ( const auto& pr : _Simulation->_KeepFars )
            {
               XYZ a = _Simulation->_Graph->posOf( pr.a );
               XYZ b = _Simulation->_Graph->posOf( pr.b );
               if ( a.distanceToPoint( b ) > 1. - TOLERANCE )
                  continue;

               painter.drawLine( toBitmap( a ), toBitmap( b ) );
            }
         }
      }

   return image;
}