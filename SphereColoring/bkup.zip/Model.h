#pragma once

#include <vector>
#include <QDebug>
#include <QMatrix4x4>
#include <QPolygon>
#include <unordered_map>
#include <unordered_set>
#include <functional>

using namespace std;


static int mod( int x, int m ) { return (x%m+m)%m; }

class Perm
{
public:
   Perm() {}
   Perm( int n ) { for ( int i = 0; i < n; i++ ) v.push_back( i ); }
   Perm( const vector<int>& v ) : v(v) {}
   int operator[]( int idx ) const { return v[idx]; }
   int& operator[]( int idx ) { return v[idx]; }

   Perm operator*( const Perm& rhs ) const
   {
      Perm ret;
      for ( int i = 0; i < (int) v.size(); i++ )
         ret.v.push_back( rhs[v[i]] );
      return ret;
   }
   Perm inverted() const
   {
      Perm ret( v.size() );
      for ( int i = 0; i < (int) v.size(); i++ )
         ret[v[i]] = i;
      return ret;
   }
   Perm pow( int n ) const
   {
      Perm ret( v.size() );
      for ( int i = 0; i < n; i++ )
         ret = *this * ret;
      return ret;
   }
   bool circularlyMatches( const Perm& rhs ) const
   {
      int idxOffset = rhs.inverted()[v[0]];
      for ( int i = 0; i < (int) rhs.v.size(); i++ )
         if ( v[i] != rhs[mod(i+idxOffset,(int)v.size())] )
            return false;
      return true;
   }

public:
   vector<int> v;
};
static QDebug operator<<( const QDebug& d, const Perm& perm ) { return d << perm.v; }



const double PHI = .5 + sqrt(1.25);

typedef QVector3D XYZ;



bool isClockwiseTri( const QPolygonF& poly );

QMatrix4x4 toMatrix( const XYZ& a, const XYZ& b, const XYZ& c );
QMatrix4x4 translation( const XYZ& p );
QMatrix4x4 map( const vector<XYZ>& a, const vector<XYZ>& b );
QMatrix4x4 pow( const QMatrix4x4& m, int power );
bool fuzzyCompare( const QMatrix4x4& a, const QMatrix4x4& b );

class IcoSymmetry
{
public:
   struct Config
   {
      QMatrix4x4 m;
      vector<int> state;
   };

public:
   IcoSymmetry() 
   {
      _Pts = { XYZ(    -1,    0, -PHI )  
         , XYZ(     1,    0, -PHI )  
         , XYZ(     0,  PHI,   -1 )  
         , XYZ(  -PHI,    1,    0 )  
         , XYZ(  -PHI,   -1,    0 )  
         , XYZ(     0, -PHI,   -1 )
         , XYZ(     1,    0,  PHI )  
         , XYZ(    -1,    0,  PHI )  
         , XYZ(     0, -PHI,    1 )  
         , XYZ(   PHI,   -1,    0 )  
         , XYZ(   PHI,    1,    0 )  
         , XYZ(     0,  PHI,    1 ) };
   }
   XYZ operator[]( int idx ) const { return _Pts[idx]; }
   QMatrix4x4 map( const vector<int>& a, const vector<int>& b ) const
   {
      return ::map( vector<XYZ> { _Pts[a[0]], _Pts[a[1]], _Pts[a[2]] }, vector<XYZ> { _Pts[b[0]], _Pts[b[1]], _Pts[b[2]] } );
   }
   vector<Config> matrices() const
   {
      vector<Config> ret;

      for ( int sym0 : { 0, 1, 2 } )
      for ( int sym1 : { 0, 1 } )
      for ( int sym2 : { 0, 1 } )
      for ( int sym3 : { 0, 1, 2, 3, 4 } )
      {
         QMatrix4x4 m = pow( map( {0,1,2}, {3,0,2} ), sym3 )
            * pow( map( {0,1,2}, {7,6,8} ), sym2 )
            * pow( map( {0,1,2}, {1,0,5} ), sym1 )
            * pow( map( {0,1,2}, {1,2,0} ), sym0 );
         ret.push_back( Config { m, {sym0,sym1,sym2,sym3} } );
      }
      return ret;
   }
   int id( const XYZ& p ) const
   {
      for ( int i = 0; i < (int) _Pts.size(); i++ )
         if ( _Pts[i].distanceToPoint( p ) < 1e-5 )
            return i;
      throw 777;
   }
   //vector<int> colorPerm( const QMatrix4x4& m ) const
   //{
   //   vector<int> ret = {0,1,2,3,4,5,6};      
   //   for ( int i = 0; i < 6; i++ )
   //      ret[i] = id( m * _Pts[i] ) % 6;
   //   return ret;
   //}
   double radius() const { return _Pts[0].length(); }

   Perm colorPermOf( const QMatrix4x4& m ) const
   {
      return Perm( { id( m*_Pts[0] )%6, id( m*_Pts[1] )%6, id( m*_Pts[2] )%6, id( m*_Pts[3] )%6, id( m*_Pts[4] )%6, id( m*_Pts[5] )%6, 6} );        
   }

public:
   vector<XYZ> _Pts;
};

class TileDot
{
public:
   class Neighbor
   {
   public:
      Neighbor( int index, const QMatrix4x4& mtx, bool isSymmetrical ) : _Index(index), _Mtx(mtx), _IsSymmetrical(isSymmetrical) {}

      int _Index;
      QMatrix4x4 _Mtx;
      bool _IsSymmetrical;

      Neighbor operator*( const QMatrix4x4& m ) const { return Neighbor( _Index, _Mtx * m, _IsSymmetrical ); }
      Neighbor preMul( const QMatrix4x4& m ) const { return Neighbor( _Index, m * _Mtx, _IsSymmetrical ); }
      bool operator==( const Neighbor& rhs ) const { return _Index == rhs._Index && ( fuzzyCompare( _Mtx, rhs._Mtx ) || _IsSymmetrical ); }
   };

public:
   TileDot( int index, const QPoint& gridPos, const XYZ& pos, int color ) : _Index(index), _GridPos( gridPos ), _Pos(pos), _Color(color) {}
   int neighborIndex( const Neighbor& neighb ) const
   {
      for ( int i = 0; i < (int)_Neighbors.size(); i++ )
         if ( _Neighbors[i] == neighb )
            return i;
      throw 777;
   }
   Neighbor nextNeighbor( const Neighbor& neighb ) const
   {
      return _Neighbors[mod( neighborIndex( neighb ) + 1, (int) _Neighbors.size() )];
   }
   bool isCenter() const { return _Index == 0; }

public:
   int _Index;
   QPoint _GridPos;
   XYZ _Pos;
   int _Color;
   vector<Neighbor> _Neighbors;
};

class TileDots
{
public:
   void add( const TileDot& tileDot ) 
   { 
      v.push_back( tileDot );
      _ToIndex[tileDot._GridPos.y()][tileDot._GridPos.x()] = v.back()._Index;
   }
   int size() const { return (int) v.size(); }
   vector<TileDot>& arr() { return v; }
   const vector<TileDot>& arr() const { return v; }
   const TileDot& operator[]( int idx ) const { return v[idx]; }

   bool isTileAt( const QPoint& pos ) const { return _ToIndex.count( pos.y() ) && _ToIndex.at( pos.y() ).count( pos.x() ); }
   const TileDot& tileAt( const QPoint& pos ) const { return v[_ToIndex.at( pos.y() ).at( pos.x() )]; }

   void sortNeighbors();
   XYZ posOf( const TileDot::Neighbor& a ) const { return a._Mtx * v[a._Index]._Pos; }

   TileDot::Neighbor nextNeighbor( const TileDot::Neighbor& a, const TileDot::Neighbor& b ) const
   {
      return v[a._Index].nextNeighbor( b.preMul( a._Mtx.inverted() ) ).preMul( a._Mtx );
      //qDebug() << "---";
      //qDebug() << a._Index << posOf( a );
      //qDebug() << b._Index << posOf( b );
      //TileDot::Neighbor ret = v[a._Index].nextNeighbor( b.preMul( a._Mtx.inverted() ) ).preMul( a._Mtx );
      //qDebug() << ret._Index << posOf( ret );
      //return ret;
   }
   
   vector<TileDot::Neighbor> polygonForEdge( const TileDot::Neighbor& a, const TileDot::Neighbor& b ) const
   {   
      vector<TileDot::Neighbor> ret = { a, b };
      while ( true )
      {
         TileDot::Neighbor c = nextNeighbor( ret.back(), ret[ret.size()-2] );
         if ( c == ret[0] )
            break;
         ret.push_back( c );
      }
      return ret;
   }
     
private:
   vector<TileDot> v;
   unordered_map<int, unordered_map<int, int>> _ToIndex;
};

TileDots generateSphereColoringDots( int numExtensions );


//
//class Graph
//{
//public:
//   class Vertex
//   {
//   public:
//      Vertex( int index, const XYZ& pos ) : _Index(index), _Pos(pos) {}
//
//   public:
//      int _Index;
//      XYZ _Pos;   
//   };
//
//   class VertexPtr
//   {
//   public:
//      VertexPtr( Graph* graph, int index, const QMatrix4x4& m ) : _Graph(graph), _Index(index), _Mtx(m) {}
//
//      XYZ pos() const { return _Mtx * _Graph->_Vertices[_Index]._Pos; }
//
//   public:
//      Graph* _Graph;
//      int _Index;
//      QMatrix4x4 _Mtx;
//   };
//
//   class Tile
//   {
//   public:
//      vector<VertexPtr> _Vertices;
//      int _Color;
//   };
//
//   Graph( const TileDots& tileDots );
//
//
//public:
//   vector<Vertex> _Vertices;
//   vector<Tile> _Tiles;
//};

class HexCoords
{
public:
   HexCoords( int extensions ) : EXTENSIONS(extensions), _Center( -.73, -.23, 0 )
   {
      XYZ ico0 = _Ico[0];
      XYZ ico01 = (( _Ico[0] + _Ico[1] ) / 2).normalized() * _Ico.radius();
      XYZ ico02 = (( _Ico[0] + _Ico[2] ) / 2).normalized() * _Ico.radius();
      XYZ ico012 = (( _Ico[0] + _Ico[1] + _Ico[2] ) / 3).normalized() * _Ico.radius();
      XYZ ico015 = (( _Ico[0] + _Ico[1] + _Ico[5] ) / 3).normalized() * _Ico.radius();
      XYZ ico1 = _Ico[1];
      _Icos = vector<vector<XYZ>> { { ico0, ico01, ico012, XYZ(0,0,0) }
         , { ico0, ico02, ico012, XYZ(0,0,0) }
         , { ico0, ico01, ico015, XYZ(0,0,0) }
         , { ico1, ico01, ico012, XYZ(0,0,0) }
      , { ico1, ico01, ico015, XYZ(0,0,0) } };

      XYZ hex0 = _Center;
      XYZ hex01 = XYZ( 11.5 + EXTENSIONS*7, 2.5, 0 );
      XYZ hex012 = XYZ( 17/3. + EXTENSIONS*14./3, 35/3. + EXTENSIONS*14./3, 0 );
      XYZ hex02 = XYZ( -3.5, 15 - 1e-5 + EXTENSIONS*7, 0 );
      XYZ hex015 = XYZ( 11.5 + EXTENSIONS*7, 2.5, 0 )*2 - XYZ( 17/3. + EXTENSIONS*14./3, 35/3. + EXTENSIONS*14./3, 0 );
      XYZ hex1 = 2*XYZ( 11.5 + EXTENSIONS*7, 2.5, 0 ) - hex0;

      _HexToModels = vector<QMatrix4x4> {
         ::map( { hex0, hex01, hex012, XYZ(0,0,1) }, _Icos[0] ),
         ::map( { hex0, hex02, hex012, XYZ(0,0,1) }, _Icos[1] ),
         ::map( { hex0, hex01, hex015, XYZ(0,0,1) }, _Icos[2] ),
         ::map( { hex1, hex01, hex012, XYZ(0,0,1) }, _Icos[3] ),
         ::map( { hex1, hex01, hex015, XYZ(0,0,1) }, _Icos[4] )
      };
   }
   static QPoint dir( int dir )
   {      
      static QPoint s_dirs[] = { QPoint( 0, 1 ), QPoint( 1, 0 ), QPoint( 1, -1 ), QPoint( 0, -1 ), QPoint( -1, 0 ), QPoint( -1, 1 ) };
      return s_dirs[mod(dir,6)];
   }
   
   XYZ toIcoCoord( const QPoint& pt ) const
   {
      XYZ ret;
      if ( toIcoCoordX( pt, ret ) )
         return ret;
      if ( toIcoCoordX( QPoint( 23-pt.y()-pt.x()+EXTENSIONS*14, 6+pt.x() ), ret ) )
         return _Ico.map( {0,1,2}, {2,0,1} ) * ret;
      if ( toIcoCoordX( QPoint( pt.y()-6, 29-pt.x()-pt.y()+EXTENSIONS*14 ), ret ) )
         return _Ico.map( {0,1,2}, {1,2,0} ) * ret;

      return _Ico[2];
      throw 777;
   }

   vector<QPoint> transformed( const vector<QPoint>& v, function<QPoint( const QPoint& )> f ) const
   {      
      vector<QPoint> ret;
      for ( const QPoint& p : v )
         ret.push_back( f( p ) );
      return ret;
   }
   QPoint rotatedCCW( const QPoint& p ) const { return QPoint( -1-p.y(), p.x()+p.y()+1 ); }
   vector<QPoint> rotatedCCW( const vector<QPoint>& v ) const { return transformed( v, [&]( const QPoint& p ) { return rotatedCCW( p ); } ); }
   QPoint rotatedCW( const QPoint& p ) const { return QPoint( p.x() + p.y(), -1-p.x() ); }
   vector<QPoint> rotatedCW( const vector<QPoint>& v ) const { return transformed( v, [&]( const QPoint& p ) { return rotatedCW( p ); } ); }
   QPoint rotated012CCW( const QPoint& p ) const { return QPoint( 23-p.y()-p.x()+EXTENSIONS*14, 6+p.x() ); }
   vector<QPoint> rotated012CCW( const vector<QPoint>& v ) const { return transformed( v, [&]( const QPoint& p ) { return rotated012CCW( p ); } ); }
   QPoint rotated012CW( const QPoint& p ) const { return QPoint( p.y()-6, 29-p.x()-p.y()+EXTENSIONS*14 ); }
   vector<QPoint> rotated012CW( const vector<QPoint>& v ) const { return transformed( v, [&]( const QPoint& p ) { return rotated012CW( p ); } ); }
   QPoint rotated01( const QPoint& p ) const { return QPoint( 23-p.x()+EXTENSIONS*14, 5-p.y() ); }
   vector<QPoint> rotated01( const vector<QPoint>& v ) const { return transformed( v, [&]( const QPoint& p ) { return rotated01( p ); } ); }

private:
   bool toIcoCoordX( const QPoint& pt, XYZ& ret ) const
   {
      if ( pt == QPoint(-1,0) )
      { 
         ret = _Ico[0]; 
         return true; 
      }
      if ( EXTENSIONS == 2 && pt == QPoint(15+(EXTENSIONS-2)*14,21+(EXTENSIONS-2)*14) )
      { 
         ret = (( _Ico[0] + _Ico[1] + _Ico[2] ) / 3).normalized() * _Ico.radius(); 
         return true; 
      }
      if ( pt.x() < 0 )
      { 
         if ( !toIcoCoordX( QPoint( pt.x()+pt.y(), -1-pt.x() ), ret ) )
            return false;
         ret = _Ico.map( {0,1,2}, {0,2,3} ) * ret;
         return true;
      }
      if ( pt.y() < 0 )
      {
         if ( !toIcoCoordX( QPoint( -1-pt.y(), pt.x()+pt.y()+1 ), ret ) )
            return false;
         ret = _Ico.map( {0,1,2}, {0,5,1} ) * ret;
         return true;
      }

      for ( int i = 0; i < (int) _HexToModels.size(); i++ )
      {
         ret = _HexToModels[i] * XYZ( pt.x(), pt.y(), 0 );
         XYZ icoWeights = toMatrix( _Icos[i][0], _Icos[i][1], _Icos[i][2] ).inverted() * ret;
         if ( icoWeights.x() < 0 || icoWeights.y() < 0 || icoWeights.z() < 0 )
            continue; // check if pattern is past the surface         
         return true;
      }

      return false;
   }

public:
   IcoSymmetry _Ico;
   int EXTENSIONS;
   XYZ _Center;
   vector<QMatrix4x4> _HexToModels;
   vector<vector<XYZ>> _Icos;
};

class Graph
{
public:
   class VertexPtr
   {
   public:
      VertexPtr() : _Index(-1) {}
      VertexPtr( int idx, const QMatrix4x4& mtx ) : _Index(idx), _Mtx(mtx) {}
      bool isValid() const { return _Index >= 0; }
      VertexPtr premul( const QMatrix4x4& mtx ) const { return VertexPtr( _Index, mtx * _Mtx ); }
      uint64_t id() const;

      int _Index;
      QMatrix4x4 _Mtx;
   };
   class TilePtr
   {
   public:
      TilePtr() : _Index(-1) {}
      TilePtr( int idx, const QMatrix4x4& mtx ) : _Index(idx), _Mtx(mtx) {}
      TilePtr premul( const QMatrix4x4& mtx ) const { return TilePtr( _Index, mtx * _Mtx ); }
      bool isValid() const { return _Index >= 0; }
      bool operator==( const TilePtr& rhs ) const;
      int _Index;
      QMatrix4x4 _Mtx;
   };
   class Vertex
   {
   public:
      Vertex( int idx, const vector<QPoint>& hexPos ) : _Index(idx), _HexPos(hexPos) {}
      int64_t hexPosId() const { return hexPosId( _HexPos ); }
      static int64_t hexPosId( const vector<QPoint>& hexPos )
      {
         QPoint avg12;
         for ( const QPoint& p : hexPos )
            avg12 += p;
         avg12 *= 12 / (int)hexPos.size();
         return avg12.x() + avg12.y() * 1000000000LL;
      }

      int _Index;
      bool _IsSymmetrical;
      XYZ _Pos;
      vector<QPoint> _HexPos;
      vector<VertexPtr> _Neighbors;
      vector<TilePtr> _Tiles;
   };
   class Tile
   {
   public:
      int _Color;
      vector<VertexPtr> _Vertices;
      bool _IsSymmetrical = false;

      bool hasVertex( const VertexPtr& a ) const { 
         for ( const VertexPtr& b : _Vertices )
            if ( a._Index == b._Index && fuzzyCompare( a._Mtx, b._Mtx ) )
               return true;
         return false;
      }
   };
   struct VertexPair
   {
      VertexPtr a;
      VertexPtr b;
   };

public:
   Graph( int EXTENSIONS );
   XYZ posOf( const VertexPtr& vtx ) const;
   XYZ originalPosOf( const VertexPtr& vtx ) const;
   VertexPtr vertexAt( const vector<QPoint>& hexPos ) const;
   vector<VertexPtr> neighbors( const VertexPtr& vtx ) const;
   vector<VertexPtr> neighbors( const VertexPtr& vtx, int depth ) const;
   VertexPtr operator[]( int idx ) const { return VertexPtr( idx, QMatrix4x4() ); }
   vector<int> colorsAt( const VertexPtr& vtx ) const;
   uint32_t colorBits( const VertexPtr& vtx ) const;
   int colorOf( const TilePtr& tile ) const;
   vector<TilePtr> tilesAt( const VertexPtr& vtx ) const;
   TilePtr tileWithColor( const VertexPtr& vtx, int color ) const;
   bool canBeClose( const VertexPtr& a, const VertexPtr& b ) const;
   bool canBeFar( const VertexPtr& a, const VertexPtr& b ) const;
   bool eq( const TilePtr& a, const TilePtr& b ) const;
   bool eq( const VertexPtr& a, const VertexPtr& b ) const;
   vector<VertexPtr> rawVertices() const;
   vector<VertexPair> calcKeepNear() const;
   vector<VertexPair> calcKeepFar() const;

private:
   void neighbors( const VertexPtr& vtx, int depth, vector<VertexPtr>& v, unordered_set<uint64_t>& st ) const;

public:
   HexCoords _HexCoords;
   IcoSymmetry _Ico;
   int EXTENSIONS;


   vector<Vertex> _Vertices;
   vector<Tile> _Tiles;

   unordered_map<int64_t, int> _HexIdToVertexIndex;
};